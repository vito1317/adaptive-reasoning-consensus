Supplementary material for "TACT: Trust-Anchored Confidence Tempering".

Anonymized for double-blind review: names, e-mail addresses, the repository
URL and absolute paths have been replaced throughout.

Reproducing the tables:
  pip install -r requirements.txt
  pytest -q                                     # 102 tests
  python experiments/run_tact_eval.py           # Tables 1-2 (synthetic)
  python experiments/run_group_eval.py          # Table 3 (heterogeneity)
  python experiments/run_seed_dispersion.py     # seed intervals
  python experiments/run_cap_ablation.py        # cap ablation
  python experiments/run_tact_hard_eval.py      # real-trace campaign
  python experiments/run_g1_window.py           # window measurement
  python experiments/run_abstention_identifiability.py
                                                # finding (e): is the
                                                # abstention a mechanism?
  python experiments/run_planted_sensitivity.py # finding (f): planted-channel
                                                # operating characteristic
  python experiments/check_paper_numbers.py     # cross-checks every figure in
                                                # the paper against results/
Cached traces are in data/, so no API key is needed to reproduce any table.
